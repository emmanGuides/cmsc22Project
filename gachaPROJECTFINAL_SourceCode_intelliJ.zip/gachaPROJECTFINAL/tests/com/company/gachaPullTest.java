package com.company;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

class gachaPullTest {

    /***
     * basically tests that will test the consistency of each classification of drops from the drawer.
     * should be at the expected amount.
     */

    Scanner s = new Scanner(System.in);
    @Test   //test for four stars and their frequency. AT LEAST 1 four Star every 10 pulls.
    void fourStarCount() {
        int gotFour = 0;
        defaultBannerElements bann = new defaultBannerElements();
        ArrayList<String> fiveStarTester = new ArrayList<>(Arrays.asList(bann.getCharacterArray()));
        ArrayList<String> fourStarTester = new ArrayList<>(Arrays.asList(bann.getFourStarArray()));
        ArrayList<String> fiveStarWeapTester = new ArrayList<>(Arrays.asList(bann.getWeaponArray()));
        ArrayList<String> threeStarTester = new ArrayList<>(Arrays.asList(bann.getThreeStarArray()));

        boolean check = false;
        int i;
        for(i = 1; i < 181; i++){
            String pull = gachaPull.drawer(.006,.051,fiveStarTester,fiveStarWeapTester,fourStarTester,threeStarTester);
            if(pull.substring(0,5).equalsIgnoreCase("4* - ")){
                gotFour++;
            }
        }

        //1 4 star every 10 pulls.
        if((i/10)<=gotFour){
            check = true;
        }

        assertTrue(check,"Four stars received not enough.");

    }

    @Test   //test for five stars and their frequency. AT LEAST 1 five Star every 90 pulls.
    void fiveStarCount() {
        int gotFive = 0;
        defaultBannerElements bann = new defaultBannerElements();
        ArrayList<String> fiveStarTester = new ArrayList<>(Arrays.asList(bann.getCharacterArray()));
        ArrayList<String> fourStarTester = new ArrayList<>(Arrays.asList(bann.getFourStarArray()));
        ArrayList<String> fiveStarWeapTester = new ArrayList<>(Arrays.asList(bann.getWeaponArray()));
        ArrayList<String> threeStarTester = new ArrayList<>(Arrays.asList(bann.getThreeStarArray()));

        boolean check = false;
        int i;
        for(i = 1; i < 181; i++){
            String pull = gachaPull.drawer(.006,.051,fiveStarTester,fiveStarWeapTester,fourStarTester,threeStarTester);
            if(pull.substring(0,5).equalsIgnoreCase("5* - ")){
                gotFive++;
            }
        }

        if((i/90)<=gotFive){
            check = true;
        }
        assertTrue(check,"Five stars received not enough.");
    }

    @Test   //check if the Tally of 3 stars in the code works properly.
    void checkThreeStarCount(){
        int gotThree = 0;
        defaultBannerElements bann = new defaultBannerElements();
        ArrayList<String> fiveStarTester = new ArrayList<>(Arrays.asList(bann.getCharacterArray()));
        ArrayList<String> fourStarTester = new ArrayList<>(Arrays.asList(bann.getFourStarArray()));
        ArrayList<String> fiveStarWeapTester = new ArrayList<>(Arrays.asList(bann.getWeaponArray()));
        ArrayList<String> threeStarTester = new ArrayList<>(Arrays.asList(bann.getThreeStarArray()));

        int i;
        for(i = 1; i < 181; i++){
            String pull = gachaPull.drawer(.006,.051,fiveStarTester,fiveStarWeapTester,fourStarTester,threeStarTester);
            if(pull.substring(0,4).equalsIgnoreCase("3* - ")){
                gotThree++;
            }
        }
        assertEquals(gachaPull.getThreeStarsCounter(), gotThree);
    }

    @Test   //check if the Tally of 4 stars in the code works properly.
    void checkFourStarCount(){
        int gotFour = 0;
        defaultBannerElements bann = new defaultBannerElements();
        ArrayList<String> fiveStarTester = new ArrayList<>(Arrays.asList(bann.getCharacterArray()));
        ArrayList<String> fourStarTester = new ArrayList<>(Arrays.asList(bann.getFourStarArray()));
        ArrayList<String> fiveStarWeapTester = new ArrayList<>(Arrays.asList(bann.getWeaponArray()));
        ArrayList<String> threeStarTester = new ArrayList<>(Arrays.asList(bann.getThreeStarArray()));

        int i;
        for(i = 1; i < 181; i++){
            String pull = gachaPull.drawer(.006,.051,fiveStarTester,fiveStarWeapTester,fourStarTester,threeStarTester);
            if(pull.substring(0,4).equalsIgnoreCase("4* - ")){
                gotFour++;
            }
        }
        assertEquals(gachaPull.getThreeStarsCounter(), gotFour);
    }

    @Test  //check if the Tally of 5 stars in the code works properly.
    void checkFiveStarCount(){
        int gotFive = 0;
        defaultBannerElements bann = new defaultBannerElements();
        ArrayList<String> fiveStarTester = new ArrayList<>(Arrays.asList(bann.getCharacterArray()));
        ArrayList<String> fourStarTester = new ArrayList<>(Arrays.asList(bann.getFourStarArray()));
        ArrayList<String> fiveStarWeapTester = new ArrayList<>(Arrays.asList(bann.getWeaponArray()));
        ArrayList<String> threeStarTester = new ArrayList<>(Arrays.asList(bann.getThreeStarArray()));

        int i;
        for(i = 1; i < 181; i++){
            String pull = gachaPull.drawer(.006,.051,fiveStarTester,fiveStarWeapTester,fourStarTester,threeStarTester);
            if(pull.substring(0,4).equalsIgnoreCase("5* - ")){
                gotFive++;
            }
        }
        assertEquals(gachaPull.getThreeStarsCounter(), gotFive);
    }
}