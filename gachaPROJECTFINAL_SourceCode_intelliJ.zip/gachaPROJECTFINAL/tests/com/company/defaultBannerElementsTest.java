package com.company;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class defaultBannerElementsTest {
    defaultBannerElements bann = new defaultBannerElements();

    @Test
    void getCharacterArray() {
        assertArrayEquals(bann.getCharacterArray(), fiveStar);
    }

    @Test
    void getFourStarArray() {
        assertArrayEquals(bann.getFourStarArray(), fourStar);
    }

    @Test
    void getWeaponArray() {
        assertArrayEquals(bann.getWeaponArray(), weapon5Star);
    }

    @Test
    void getThreeStarArray() {
        assertArrayEquals(bann.getThreeStarArray(), threeStar);
    }



    /***
     * below are the correct arrays, tests will check if getters work properly.
     */


    String[] fiveStar = {"5* - Jean", "5* - Diluc", "5* - Qiqi", "5* - Mona", "5* - Keqing"};

    String[] fourStar = {"4* - Amber", "4* - Lisa", "4* - Kaeya", "4* - Barbara", "4* - Razor",
            "4* - Bennet", "4* - Noelle", "4* - Fischl", "4* - Sucrose", "4* - Beidou", "4* - Ningguang", "4* - Xiangling", "4* - Xinqiu",
            "4* - Chongyun", "4* - Diona", "4* - Xinyan", "4* - Dragon's Bane", "4* - Eye of Perception", "4* - Favonius Sword",
            "4* - Favonius Codex", "4* - Favonius Greatsword", "4* - Favonius Lance", "4* - Favonius Warbow",
            "4* - Lion's Roar" ,"4* - Rainslasher", "4* - Rust", "4* - Sacrificial Bow", "4* - Sacrificial Fragments",
            "4* - Sacrificial Greatsword","4* - Sacrificial Sword", "4* - The Bell", "4* - The Stringless", "4* - The Flute",
            "4* - The Widsith"};

    String[] threeStar = {"3* - Thrilling tales","3* - Magic Guide","3* - Slingshot ",
            "3* - Sharpshooter's Oath", "3* - Harbinger of Dawn","3* - Fillet Blade","3* - Cool Steel","3* - Black Tassel",
            "3* - Debate Club","3* - Bloodtainted Greatsword", "3* - White Tassel","3* - Skyrider Greatsword",
            "3* - Ferrous Shadow","3* - Messenger","3* - Otherwordly Story","3* - Quartz","3* - Raven Bow",
            "3* - Recurve Bow","3* - Skyrider Sword","3* - Traveler's Handy Sword", "3* - Twin Nephrite"};

    String[] weapon5Star = {"5* - Skyward Pride",
            "5* - Skyward Harp", "5* - Skyward Atlas", "5* -Skyward Sword",
            "5* - Skyward Harp", "5* - Aquila Favonia", "5* - Wolf's Gravestone",
            "5* - Winged Jade Spear", "5* - Amos' Bow","5* - Lost Prayer to the Sacred Isles"};

}