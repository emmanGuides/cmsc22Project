package com.company;

import java.util.ArrayList;

/***
 * class banners with constructor to be used in the other classes
 */
public class banners {
    public banners(ArrayList<String> input, double rate) {
        this.input = input;
        this.rate = rate;
    }

    private ArrayList<String> input;
    private double rate;

    public ArrayList<String> getInput() {
        return input;
    }

    public double getRate() {
        return rate;
    }
}
