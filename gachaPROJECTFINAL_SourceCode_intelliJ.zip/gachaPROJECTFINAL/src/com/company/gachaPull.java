package com.company;

import java.lang.Math;
import java.util.*;

/***
 *
 */
public class gachaPull {

    /***
     * variables needed are below.
     *
     *
     * mathRand is a double that varies between [0,1.0], these are the percentages (in decimal), in which,
     * for a standard 5 star with a drop rate of .6% to drop, mathRand should be equal to, or lesser than .006
     *
     * innerRandomNum is another Randomizing variable that has a varying boundary. It has multiple uses,
     * from choosing between a random element in a particular ArrayList<String>, or from determining
     * from the 5 Star 50/50 drop rate whenever it procs, if it would return a String from the Weapons
     * ArrayList (50%), or from the Characters Arraylist(50%).
     *
     * pityCounter90 is the pity for the 5 stars, in which, even if whatever happens with the
     * mathRand that determines each pull, if it hits 90, it will 100% drop a 5 star.
     *
     * pityCounter10 is the pity for 4 stars. every 10 pulls, no matter what, a guaranteed
     * 4 star is dropped.
     */

    static Random rand = new Random(System.currentTimeMillis());
    private static int pityCounter90 = 0, pityCounter10 = 0; static int innerRandomNum;
    static int threeStarsCounter, fourStarsCounter, fiveStarsCounter;
    static double mathRand; static String returnValue = "";

    /***
     * drawer takes in the parameters below and returns a String value after processing through the probabilities and
     * rules of this gacha.
     *Important: There is a 'Soft Pity' System in this Gacha, in which, when pityCounter90 reaches 60 and above,
     * the chances of 5star and 4 star drops increases too.
     *
     * @param rate5      basically the 5 star drop rate of your choosing. necessary because in the personalized banner, this
     *                   can be customized. percentage comes in decimal form (Double)
     *
     * @param rate4      same with the rate5, but just for Four stars.
     *
     * @param whatFiveStarChar  takes in an ArrayList<String> as a parameter. needed for 5 star
     *                          characters in customizable banner.
     *
     * @param whatFiveStarWeap  works the same way as above, but for 5 star weapons
     *
     * @param whatFourStar      works the same way as above, but for 4 star drops.
     *
     * @param whatThreeStar     works the same way as above, but for 3 star drops.
     *
     * @return                  returns returnValue as String, after processing through the Arraylists
     *                          and chances that are provided
     */

    static String drawer(double rate5, double rate4, ArrayList<String> whatFiveStarChar,ArrayList<String> whatFiveStarWeap, ArrayList<String> whatFourStar, ArrayList<String> whatThreeStar){
        mathRand = Math.random(); pityCounter10++; pityCounter90++;


        if(pityCounter90 >= 90) {       //5star pity hit
            innerRandomNum = rand.nextInt(2);
            if(innerRandomNum == 1){    //weapons
                innerRandomNum = rand.nextInt(whatFiveStarWeap.size());
                pityCounter90 = 0;
                returnValue = whatFiveStarWeap.get(innerRandomNum);
            }else{ //character
                innerRandomNum = rand.nextInt(whatFiveStarChar.size());
                pityCounter90 = 0;
                returnValue = whatFiveStarChar.get(innerRandomNum);
            }
        }
        else if(pityCounter10 >= 10) {   //4 star pity hit
            innerRandomNum = rand.nextInt(whatFourStar.size());
            pityCounter10 = 0;
            returnValue = whatFourStar.get(innerRandomNum);
        }
        else if(pityCounter90 > 60){                            //soft pity at around 60+ draws without a five star
            if(mathRand <= rate5*40){                           //hit 5 star with soft pity
                innerRandomNum = rand.nextInt(2);
                if(innerRandomNum == 1){                        //hit weapon
                    innerRandomNum = rand.nextInt(whatFiveStarWeap.size());
                    pityCounter90 = 0;
                    returnValue = whatFiveStarWeap.get(innerRandomNum);
                }
                else
                {                                               //hit character
                    innerRandomNum = rand.nextInt(whatFiveStarChar.size());
                    pityCounter90 = 0;
                    returnValue = whatFiveStarChar.get(innerRandomNum);
                }
            }
            else if(mathRand <= rate4 * 10){                    //4star pull on a Soft Pity
                innerRandomNum = rand.nextInt(whatFourStar.size());
                pityCounter10 = 0;
                returnValue = whatFourStar.get(innerRandomNum);
            }
            else{
                innerRandomNum = rand.nextInt(whatThreeStar.size());
                returnValue = whatThreeStar.get(innerRandomNum);
            }
        }
        else{                                           //no soft or hard pity, pure luck
            if(mathRand <= rate5){
                innerRandomNum = rand.nextInt(2);
                if(innerRandomNum == 1){ //hit weapon
                    innerRandomNum = rand.nextInt(whatFiveStarWeap.size());
                    pityCounter90 = 0;
                    returnValue = whatFiveStarWeap.get(innerRandomNum);
                }else{ //hit character
                    innerRandomNum = rand.nextInt(whatFiveStarChar.size());
                    pityCounter90 = 0;
                    returnValue = whatFiveStarChar.get(innerRandomNum);
                }

            }
            else if(mathRand <= rate4){
                innerRandomNum = rand.nextInt(whatFourStar.size());
                pityCounter10 = 0;
                returnValue = whatFourStar.get(innerRandomNum);
            }
            else{
                innerRandomNum = rand.nextInt(whatThreeStar.size());
                returnValue = whatThreeStar.get(innerRandomNum);
            }
        }
        return returnValue;

    }

    public static int getPityCounter90() {
        return pityCounter90;
    }

    public static int getPityCounter10() {
        return pityCounter10;
    }

    public static double getMathRand() {
        return mathRand;
    }

    public static int getThreeStarsCounter() {
        return threeStarsCounter;
    }

    public static int getFourStarsCounter() {
        return fourStarsCounter;
    }

    public static int getFiveStarsCounter() {
        return fiveStarsCounter;
    }
}
