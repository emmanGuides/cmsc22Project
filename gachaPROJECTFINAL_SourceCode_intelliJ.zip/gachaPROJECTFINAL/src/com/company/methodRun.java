package com.company;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;

/***
 * contains runCode method that passes parameters to drawer() from gachaPull
 * tallies and uses every string returned by it.
 */

public class methodRun extends gachaPull{

    static double user4StarRate = 0, user5StarRate = 0;
    static ArrayList<String> user3StarsList = new ArrayList<>();
    static ArrayList<String> user5StarList = new ArrayList<>();
    static ArrayList<String> user4StarsList = new ArrayList<>();
    static ArrayList<String> user5StarWeaponsList = new ArrayList<>();
    static banners user5Stars = new banners(user5StarList,  user5StarRate);
    static banners user5StarsWeap = new banners(user5StarWeaponsList, user5StarRate);
    static banners user4Stars = new banners(user4StarsList, user4StarRate);
    static banners user3Stars = new banners(user3StarsList, 0);
    static boolean printed = false;



    static void runCode(){

        defaultBannerElements banner = new defaultBannerElements(); int numOfPulls = 0, firstChoice = 0; boolean repeat = true;
        int fiveStarsCounter = 0, fourStarsCounter = 0, threeStarsCounter = 0;



        //hardcoded banner elements for Standard banner.
        ArrayList<String> fiveStarList = new ArrayList<>(Arrays.asList(banner.getCharacterArray()));
        banners fiveStarCharacters = new banners(fiveStarList, .006);

        ArrayList<String> fiveStarWeapList = new ArrayList<>(Arrays.asList(banner.getWeaponArray()));
        banners fiveStarWeapons = new banners(fiveStarWeapList, .006);

        ArrayList<String> fourStarList = new ArrayList<>(Arrays.asList(banner.getFourStarArray()));
        banners fourStarCharacters = new banners(fourStarList, .051);

        ArrayList<String> threeStarList = new ArrayList<>(Arrays.asList(banner.getThreeStarArray()));
        banners threeStarItems = new banners(threeStarList, 0);
        //
        //
        //

        while(repeat) {
            try
            {
                System.out.println("\nWhat do you want to do?\n[1] Pull on Standard Banner, [2] Create your own Banner!, [3] Pull on Personal Banner, [4] Quit.");
                firstChoice = getIntInput();
                repeat = false;
            }
            catch (InputMismatchException exception)
            {
                System.out.println("Only choose between the given choices. Thank you.");
                repeat = true;
            }
        }
        if(firstChoice == 1)
        {
            try {
                System.out.println("How many pulls do you want?");
                numOfPulls = getIntInput();

                for (int i = 0; i < numOfPulls; i++) {
                    String pull;
                    pull = gachaPull.drawer(fiveStarCharacters.getRate(), fourStarCharacters.getRate(), fiveStarCharacters.getInput(), fiveStarWeapons.getInput(), fourStarCharacters.getInput(), threeStarItems.getInput());
                    System.out.println("Pull number: " + (i + 1) + "/" + numOfPulls);
                    System.out.println("90 pulls pity: " + gachaPull.getPityCounter90() + ", 10 pulls' pity: " + gachaPull.getPityCounter10());
                    System.out.println(pull + "\n");

                    if (fiveStarList.contains(pull) || fiveStarWeapList.contains(pull)) {
                        fiveStarsCounter++;
                    } else if (fourStarList.contains(pull)) {
                        fourStarsCounter++;
                    } else {
                        threeStarsCounter++;
                    }

                }
                System.out.println("\n\n5 stars: " + fiveStarsCounter + "\n4 stars: " + fourStarsCounter + "\n3 Stars: " + threeStarsCounter);

            }
            catch (InputMismatchException exception){
                System.out.println("uh oh! only input Integers here!");
                runCode();
            }
        }
        else if(firstChoice == 2){

            System.out.println("First, you're going to enter your 5 stars down below. \nInput 'stop' to conclude, Input '++' to add the standard characters in.\n-> ");
            while(true){
                String userInput = getStrInput();
                if(userInput.equalsIgnoreCase("stop")){
                    if(user5StarList.isEmpty()){
                        System.out.println("You must add atleast '1' element!");
                    }else{
                        System.out.println("This is the list: "+user5StarList);
                        break;
                    }

                }else if(userInput.equalsIgnoreCase("++")){
                    user5StarList.addAll(fiveStarList);
                    System.out.println("Standard 5 stars added!");
                }
                else{
                    user5StarList.add(userInput);
                }

            }

            System.out.println("Now, input your 5 star weapons below. \nInput 'stop' to conclude.Input '++' to add the Standard 5 star weapons in.\n->");
            while(true){
                String userInput = getStrInput();
                if(userInput.equalsIgnoreCase("Stop")){
                    if(user5StarWeaponsList.isEmpty()){
                        System.out.println("You must add atleast '1' element!");
                    }else{
                        System.out.println("This is the list: "+user5StarWeaponsList);
                        break;
                    }
                }
                else if(userInput.equalsIgnoreCase("++"))
                {
                    user5StarWeaponsList.addAll(fiveStarWeapList);
                    System.out.println("Added the Standard 5 star Weapons!");
                }else{
                    user5StarWeaponsList.add(userInput);
                }
            }
            while(true) {
                try {
                    System.out.println("What rate to drop would you give these Five Stars? Input in Decimal. (ex. .06 for 6%)");
                    user5StarRate = getDoubInput();
                    break;
                } catch (InputMismatchException exception) {
                    System.out.println("Only input Decimals.");
                }
            }


            System.out.println("Now, input your 4 stars below. \nInput 'Stop' to conclude. Input '++' to add the Standard 4 stars in.");
            while(true){
                String userInput = getStrInput();
                if(userInput.equalsIgnoreCase("Stop")){
                    if(user4StarsList.isEmpty()){
                        System.out.println("Input atleast 1 element!");
                    }else{
                        System.out.println("This is the list: "+user4StarsList);
                        break;
                    }

                }else if(userInput.equalsIgnoreCase("++")){
                    user4StarsList.addAll(fourStarList);
                    System.out.println("Standard 4 stars added!");
                }
                else {
                    user4StarsList.add(userInput);
                }
            }while(true){
                try{
                    System.out.println("What rate would you give these 4 stars to drop? again, in decimal.");
                    user4StarRate = getDoubInput();
                    break;
                }catch(InputMismatchException exception){
                    System.out.println("Only input Decimals.");
                }
            }

            System.out.println("Lastly, Input your 3 stars Below. \nInput 'Stop' to Conclude, Input '++' to add the Standard 3 stars in.");
            while(true){
                String userInput = getStrInput();
                if(userInput.equalsIgnoreCase("stop")){
                    if(user3StarsList.isEmpty()){
                        System.out.println("You must add atleast '1' element!");
                    }else{
                        System.out.println("Your list is: "+user3StarsList);
                        break;
                    }
                }else if(userInput.equalsIgnoreCase("++")){
                    user3StarsList.addAll(threeStarList);
                    System.out.println("Added the standard three stars!");
                }
                else{
                    user3StarsList.add(userInput);
                }
            }


            System.out.println("User Banner Done!");
            runCode();
        }
        else if (firstChoice == 3) {

            if(user3StarsList.isEmpty() || user4StarsList.isEmpty() || user5StarList.isEmpty()){
                System.out.println("You still haven't made a Banner!");
                runCode();
            }
            else {
                try
                {
                    System.out.println("How many pulls do you want in your custom Banner?");
                    numOfPulls = getIntInput();

                    for (int i = 0; i < numOfPulls; i++) {
                        String pull;
                        pull = gachaPull.drawer(user5StarRate, user4StarRate, user5Stars.getInput(), user5StarsWeap.getInput(), user4Stars.getInput(), user3Stars.getInput());
                        System.out.println("Pull number: " + (i + 1) + "/" + numOfPulls);
                        System.out.println("90 pulls pity: " + gachaPull.getPityCounter90() + ", 10 pulls' pity: " + gachaPull.getPityCounter10());
                        System.out.println(pull + "\n");

                        if (user5StarList.contains(pull) || user5StarWeaponsList.contains(pull)) {
                            fiveStarsCounter++;
                        } else if (user4StarsList.contains(pull)) {
                            fourStarsCounter++;
                        } else {
                            threeStarsCounter++;
                        }

                    }
                    System.out.println("\n\n5 stars: " + fiveStarsCounter + "\n4 stars: " + fourStarsCounter + "\n3 Stars: " + threeStarsCounter);
                }
                catch (InputMismatchException exception)
                {
                    System.out.println("uh oh! only input Integers here!");
                    runCode();
                }

            }
        }else{
            printed = true;
        }
        if(!printed){
            System.out.println("You could've wasted "+numOfPulls*123+" Pesos already!");
            priceCheck(numOfPulls*123);
            printed = true;
        }

    }

    static void priceCheck(int input){
        if(input <=123){
            System.out.println("Could've bought some snacks with this instead.");
        }else if (input <= 500) {
            System.out.println("Could've bought a decent shirt with this instead.");
        }else if(input <= 1000){
            System.out.println("Could've treated someone in your life with a meal with this money.");
        } else if (input <= 2000){
            System.out.println("You could've bought a pair of decent Shoes with this amount!");
        }else if(input <= 5000){
            System.out.println("You could've saved this for the rainy days, yet you bought virtual items with it instead.");
        }else if(input <= 10000){
            System.out.println("Probably could've bought a decent phone with this amount already!");
        }else if(input <= 15000){
            System.out.println("You could've bought a new, yet decent Smartphone with this amount instead.");
        }else if(input <= 20000){
            System.out.println("Probably could've invested this in the stock market instead.");
        }else if(input <= 25000 ){
            System.out.println("Probably could've bought a new PC with this amount");
        }else{
            System.out.println("At this point, you should've just invested for a business really");
        }

    }

    public static int getIntInput() {
        Scanner s = new Scanner(System.in);
        return s.nextInt();
    }

    public static String getStrInput(){
        Scanner s = new Scanner(System.in);
        return s.next();
    }

    public static Double getDoubInput(){
        Scanner s = new Scanner(System.in);
        return s.nextDouble();
    }







}
